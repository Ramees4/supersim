module.exports = {
    tabWidth: 2,
    useTabs: false,
    trailingComma: 'all',
    semi: false,
    singleQuote: true,
    arrowParens: 'always',
  }
  