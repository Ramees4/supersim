import { Address } from 'viem'

export const deployment: {
  deployedAddress: Address
  ownerAddress: Address
}
